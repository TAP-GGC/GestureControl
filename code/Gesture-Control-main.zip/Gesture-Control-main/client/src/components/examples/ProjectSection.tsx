import ProjectSection from '../ProjectSection';

export default function ProjectSectionExample() {
  return (
    <div className="p-4">
      <ProjectSection />
    </div>
  );
}