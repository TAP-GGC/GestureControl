import WebcamViewer from '../WebcamViewer';

export default function WebcamViewerExample() {
  return (
    <div className="p-4">
      <WebcamViewer />
    </div>
  );
}