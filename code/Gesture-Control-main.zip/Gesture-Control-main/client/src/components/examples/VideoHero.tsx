import VideoHero from '../VideoHero';

export default function VideoHeroExample() {
  return <VideoHero />;
}